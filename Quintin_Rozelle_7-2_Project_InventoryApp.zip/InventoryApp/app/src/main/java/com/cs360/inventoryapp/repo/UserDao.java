/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp.repo;

import androidx.lifecycle.LiveData;
import androidx.room.*;

import com.cs360.inventoryapp.model.User;

import java.util.List;

@Dao
public interface UserDao {
    // Queries database for specific user
    @Query("SELECT * FROM User WHERE id = :id")
    LiveData<User> getUser(long id);

    // Queries database for all users
    @Query("SELECT * FROM User ORDER BY userName COLLATE NOCASE")
    LiveData<List<User>> getUsers();

    // Adds user to database. If conflict is found, replaces user
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addUser(User user);

    // Updates user in database
    @Update
    void updateUser(User user);

    // Deletes user in database
    @Delete
    void deleteUser(User user);
}