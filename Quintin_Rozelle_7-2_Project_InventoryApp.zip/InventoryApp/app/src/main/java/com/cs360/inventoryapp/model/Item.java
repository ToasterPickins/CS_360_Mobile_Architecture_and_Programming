/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Item {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long mId;

    @NonNull
    @ColumnInfo(name = "name")
    private String mName;

    @NonNull
    @ColumnInfo(name = "description")
    private String mDescription;

    @ColumnInfo(name = "quantity")
    private int mQuantity;

    // Constructor
    public Item(@NonNull String name, @NonNull String description, int quantity) {
        mName = name;
        mDescription = description;
        mQuantity = quantity;
    }

    // Getters and setters
    public long getId() {
        return mId;
    }

    public void setId(long id) {
        mId = id;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        mDescription = description;
    }

    public int getQuantity() {
        return mQuantity;
    }

    public void setQuantity(int quantity) {
        mQuantity = quantity;
    }
}
