/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.cs360.inventoryapp.model.Item;
import com.cs360.inventoryapp.viewmodel.ItemListViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private InventoryAdapter mInventoryAdapter;
    private RecyclerView mRecyclerView;
    private ItemListViewModel mItemListViewModel;
    private FloatingActionButton mAddFAB;
    private final SmsManager mSmsManager= SmsManager.getDefault();

    // Activity launcher. Used below to start "Add item" activity and display toast after success
    private final ActivityResultLauncher<Intent> mAddItemResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Toast.makeText(InventoryActivity.this, R.string.item_added_success, Toast.LENGTH_SHORT).show();
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Get item view model
        mItemListViewModel = new ViewModelProvider(this).get(ItemListViewModel.class);

        // Add references to views
        mAddFAB = findViewById(R.id.inventory_add_button);
        mRecyclerView = findViewById(R.id.inventory_table);

        // Add on click listeners
        mAddFAB.setOnClickListener(this::onAddClick);

        // Observe for changes to item view model and update UI upon changes
        mItemListViewModel.getItems().observe(this, this::updateUI);
    }

    // Update UI after data updates
    private void updateUI(List<Item> itemList) {
        mInventoryAdapter = new InventoryAdapter(itemList);
        mRecyclerView.setAdapter(mInventoryAdapter);
    }

    // Starts "Add item" activity
    private void onAddClick(View view) {
        Intent intent = new Intent(this, AddItem.class);
        mAddItemResultLauncher.launch(intent);
    }

    // Creates menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // Starts settings activity to toggle SMS functionality
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.settings_button) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // View holder for Recycler View
    private class InventoryHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private Item mItem;
        private final TextView mItemName;
        private final TextView mItemDescription;
        private final EditText mItemQuantity;
        private ImageButton mIncreaseButton;
        private ImageButton mDecreaseButton;
        private ImageButton mDeleteButton;

        public InventoryHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.inventory_list_item, parent, false));

            // Add references to views
            mItemName = itemView.findViewById(R.id.list_item_name);
            mItemDescription = itemView.findViewById(R.id.list_item_description);
            mItemQuantity = itemView.findViewById(R.id.list_item_quantity);
            mIncreaseButton = itemView.findViewById(R.id.list_item_increase_button);
            mDecreaseButton = itemView.findViewById(R.id.list_item_decrease_button);
            mDeleteButton = itemView.findViewById(R.id.list_item_delete_button);

            // Add onclick listeners
            itemView.setOnClickListener(this);
            mIncreaseButton.setOnClickListener(this::onIncreaseClick);
            mDecreaseButton.setOnClickListener(this::onDecreaseClick);
            mDeleteButton.setOnClickListener(this::onDeleteClick);
        }

        // Bind new items
        public void bind(Item item, int position) {
            mItem = item;
            mItemName.setText(item.getName());
            mItemDescription.setText(item.getDescription());
            Integer mItemQuantityAsInteger = item.getQuantity();
            mItemQuantity.setText(mItemQuantityAsInteger.toString());
        }

        @Override
        public void onClick(View view) {
        }

        // Increase quantity by 1
        private void onIncreaseClick(View view) {
            mItem.setQuantity(mItem.getQuantity() + 1);
            mItemListViewModel.updateItem(mItem);
        }

        // Decreases quantity by 1
        private void onDecreaseClick(View view) {
            // Only decrease quantity if above 0
            if (mItem.getQuantity() > 0) {
                mItem.setQuantity(mItem.getQuantity() - 1);
                mItemListViewModel.updateItem(mItem);
            }

            // If now at 0, send SMS (if permissions allowed) or show toast (if SMS permissions not allowed)
            if (mItem.getQuantity() == 0) {
                if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    mSmsManager.sendTextMessage("+15551234567", null, "Item: '" + mItem.getName() + "' has low inventory", null, null);
                }
                else {
                    Toast.makeText(getApplicationContext(), "Item: '" + mItem.getName() + "' has low inventory", Toast.LENGTH_SHORT).show();
                }
            }
        }

        // Deletes item from view
        private void onDeleteClick(View view) {
            mItemListViewModel.deleteItem(mItem);
        }
    }

    // Recycler view adapter
    private class InventoryAdapter extends RecyclerView.Adapter<InventoryHolder> {

        private final List<Item> mItemList;

        public InventoryAdapter(List<Item> items) {
            mItemList = items;
        }

        @NonNull
        @Override
        public InventoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new InventoryHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(InventoryHolder holder, int position) {
            holder.bind(mItemList.get(position), position);
        }

        @Override
        public int getItemCount() {
            return mItemList.size();
        }
    }
}