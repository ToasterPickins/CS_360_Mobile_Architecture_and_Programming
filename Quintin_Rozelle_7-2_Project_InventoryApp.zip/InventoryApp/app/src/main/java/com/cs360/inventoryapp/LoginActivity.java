/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cs360.inventoryapp.model.User;
import com.cs360.inventoryapp.viewmodel.UserViewModel;

import java.util.List;

public class LoginActivity extends AppCompatActivity {

    private EditText mUserName;
    private EditText mPassword;
    private Button mLoginButton;
    private Button mRegisterButton;
    private UserViewModel mUserViewModel;
    private List<User> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Get user view model
        mUserViewModel = new ViewModelProvider(this).get(UserViewModel.class);

        // Add references to views
        mUserName = findViewById(R.id.user_name_entry);
        mPassword = findViewById(R.id.password_entry);
        mLoginButton = findViewById(R.id.login_button);
        mRegisterButton = findViewById(R.id.register_button);

        // Add onClickListeners
        mLoginButton.setOnClickListener(this::onLoginClick);
        mRegisterButton.setOnClickListener(this::onRegisterClick);

        // Observe for changes to user data and update the list of users upon changes
        mUserViewModel.getUsers().observe(this, this::updateUserList);
    }

    // Updates user list on changes to user view model
    private void updateUserList(List<User> users) {
        userList = users;
    }

    // Launches inventory view activity after successful login
    private void onLoginClick(View view) {
        try {
            // Check that username and password fields aren't blank
            if (mUserName.getText().toString().equals("")) { throw new Exception("Username cannot be blank"); }
            if (mPassword.getText().toString().equals("")) { throw new Exception("Password cannot be blank"); }

            // Check that user is found in the user list and password is correct
            boolean userFound = false;
            for (User user : userList) {
                if (mUserName.getText().toString().equals(user.getUserName()) && mPassword.getText().toString().equals(user.getPassword())) {
                    userFound = true;
                    break;
                }
            }

            // If user found in user list, start inventory activity
            if (userFound) {
                Intent intent = new Intent(this, InventoryActivity.class);
                startActivity(intent);
            } else {
                // User and password combination incorrect
                Toast.makeText(LoginActivity.this, "User and password combination is incorrect", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            // Display toast if username or password are blank
            Toast.makeText(LoginActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // Adds new user to database
    private void onRegisterClick(View view) {
        try {
            // Check that username and password fields aren't blank
            if (mUserName.getText().toString().equals("")) { throw new Exception("Username cannot be blank"); }
            if (mPassword.getText().toString().equals("")) { throw new Exception("Password cannot be blank"); }

            // Searches for entered user in user list. If found, update password
            boolean userFound = false;
            for (User user : userList) {
                if (mUserName.getText().toString().equals(user.getUserName())) {
                    user.setPassword(mPassword.getText().toString());
                    Toast.makeText(LoginActivity.this, "User already present. Password updated", Toast.LENGTH_SHORT).show();
                    userFound = true;
                    break;
                }
            }

            // If user not found in user list, add new user
            if (!userFound) {
                User newUser = new User(mUserName.getText().toString(), mPassword.getText().toString());
                mUserViewModel.addUser(newUser);
                Toast.makeText(LoginActivity.this, "User added", Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {
            // Display toast if username or password are blank
            Toast.makeText(LoginActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            // Resets fields to blank entries
            mUserName.setText("");
            mPassword.setText("");
        }
    }
}