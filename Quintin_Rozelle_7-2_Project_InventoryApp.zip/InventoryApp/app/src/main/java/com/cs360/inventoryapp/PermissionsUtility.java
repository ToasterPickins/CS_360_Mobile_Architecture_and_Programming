/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp;

import android.app.Activity;
import android.content.pm.PackageManager;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionsUtility {

    // Check for supplied permission. If not found, request permission from user
    public static boolean hasPermssions(final Activity activity, final String permission, final int requestCode) {
        if (ContextCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, new String[] { permission }, requestCode);
            return false;
        }
        return true;
    }
}
