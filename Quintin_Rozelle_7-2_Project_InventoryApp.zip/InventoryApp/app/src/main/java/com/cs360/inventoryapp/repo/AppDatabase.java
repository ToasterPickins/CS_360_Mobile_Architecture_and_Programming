/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp.repo;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.cs360.inventoryapp.model.Item;
import com.cs360.inventoryapp.model.User;

@Database(entities = {Item.class, User.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    public abstract ItemDao itemDao();
    public abstract UserDao userDao();
}
