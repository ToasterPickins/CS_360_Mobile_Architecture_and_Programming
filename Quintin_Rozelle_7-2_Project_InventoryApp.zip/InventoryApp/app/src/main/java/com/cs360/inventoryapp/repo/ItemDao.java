/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp.repo;

import androidx.lifecycle.LiveData;
import androidx.room.*;

import com.cs360.inventoryapp.model.Item;

import java.util.List;

@Dao
public interface ItemDao {
    // Queries database for specific item
    @Query("SELECT * FROM Item WHERE id = :id")
    LiveData<Item> getItem(long id);

    // Queries database for all items
    @Query("SELECT * FROM Item ORDER BY name COLLATE NOCASE")
    LiveData<List<Item>> getItems();

    // Adds item to database. If conflict is found, item is replaced
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addItem(Item item);

    // Updates item in database
    @Update
    void updateItem(Item item);

    // Deletes item in database
    @Delete
    void deleteItem(Item item);
}
