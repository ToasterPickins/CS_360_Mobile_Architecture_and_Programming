/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp;

import android.os.Bundle;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreferenceCompat;
import android.Manifest;

public class SettingsActivity extends AppCompatActivity {

    // Displays settings activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.settings, new SettingsFragment())
                    .commit();
        }
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    // Display settings fragment
    public static class SettingsFragment extends PreferenceFragmentCompat {
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);

            // Find "SMS" preference
            SwitchPreferenceCompat smsPreference = findPreference("send_sms");

            // If found, set change listener
            if (smsPreference != null) {
                smsPreference.setOnPreferenceChangeListener((preference, newValue) -> {
                    // If setting turned to on, request "SEND_SMS" permissions
                    if ((Boolean) newValue) {
                        PermissionsUtility.hasPermssions(getActivity(), Manifest.permission.SEND_SMS, 0);
                    }
                    return true;
                });
            }
        }
    }
}