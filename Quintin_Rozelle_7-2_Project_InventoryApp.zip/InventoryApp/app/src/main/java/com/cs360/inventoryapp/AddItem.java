/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cs360.inventoryapp.model.Item;
import com.cs360.inventoryapp.repo.AppRepository;

// Add item activity
public class AddItem extends AppCompatActivity {

    private AppRepository mAppRepository;
    private EditText mNewItem;
    private EditText mNewDescription;
    private EditText mNewQuantity;
    private Button mAddButton;
    private Button mCancelButton;
    private Item mItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Get repository instance
        mAppRepository = AppRepository.getInstance(getApplicationContext());

        // Assign references to views
        mNewItem = findViewById(R.id.new_item);
        mNewDescription = findViewById(R.id.new_description);
        mNewQuantity = findViewById(R.id.new_quantity);
        mAddButton = findViewById(R.id.add_new_item_button);
        mCancelButton = findViewById(R.id.cancel_new_item_button);

        // Add onClickListeners
        mAddButton.setOnClickListener(this::onAddClick);
        mCancelButton.setOnClickListener(this::onCancelClick);
    }

    // Create menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // Go to settings activity if settings button clicked
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.settings_button) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Adds new item to inventory and goes back to inventory activity
    private void onAddClick(View view) {
        try {
            // Check that all fields are filled
            if (mNewItem.getText().toString().equals("")) { throw new Exception("Item name cannot be blank"); }
            if (mNewDescription.getText().toString().equals("")) { throw new Exception("Item description cannot be blank"); }
            if (mNewQuantity.getText().toString().equals("")) { throw new Exception("Item quantity cannot be blank"); }

            // Create new item and add to database
            mItem = new Item(mNewItem.getText().toString(),
                    mNewDescription.getText().toString(),
                    Integer.parseInt(mNewQuantity.getText().toString()));
            mAppRepository.addItem(mItem);

            // Return to inventory activity
            setResult(RESULT_OK);
            finish();
        } catch (Exception e) {
            // Display toast if fields are empty
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // Cancels add item and returns to inventory activity
    private void onCancelClick(View view) {
        setResult(RESULT_CANCELED);
        finish();
    }
}