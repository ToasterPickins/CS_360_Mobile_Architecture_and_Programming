/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp.repo;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.cs360.inventoryapp.model.Item;
import com.cs360.inventoryapp.model.User;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AppRepository {

    // Threadpool of 4 threads
    private static final ExecutorService mDatabaseExecutor = Executors.newFixedThreadPool(4);

    // Holds instantiated AppRepository for singleton design pattern
    private static AppRepository mAppRepository;
    private final ItemDao mItemDao;
    private final UserDao mUserDao;

    // Allows for getting the single instantiated object (or creates one if not already created)
    public static AppRepository getInstance(Context context) {
        if (mAppRepository == null) {
            mAppRepository = new AppRepository(context);
        }
        return mAppRepository;
    }

    // Private constructor - Singleton design pattern
    private AppRepository(Context context) {
        RoomDatabase.Callback databaseCallback = new RoomDatabase.Callback() {
            @Override
            public void onCreate(@NonNull SupportSQLiteDatabase db) {
                super.onCreate(db);
                // Add starter data if creating new database
                mDatabaseExecutor.execute(() -> addStarterData());
            }
        };

        AppDatabase database =
                Room.databaseBuilder(context, AppDatabase.class, "appDatabase.db")
                .addCallback(databaseCallback)
                .build();

        mItemDao = database.itemDao();
        mUserDao = database.userDao();
    }

    // Starter data for new database so app's RecyclerView isn't empty on creation and default users are added
    private void addStarterData() {
        Item item = new Item("Pencil", "No. 2. 10 count box", 10);
        addItem(item);

        item = new Item("Paper", "Copy paper. 500 sheet ream", 7);
        addItem(item);

        item = new Item("Pen", "Black. 10 count box", 4);
        addItem(item);

        item = new Item("Erasure", "20 count box", 6);
        addItem(item);

        item = new Item("Ruler", "12 inch", 2);
        addItem(item);

        item = new Item("Stapler", "Red", 6);
        addItem(item);

        item = new Item("Paper Weight", "1 lb", 8);
        addItem(item);

        item = new Item("Highlighter", "Yellow. 10 count box", 12);
        addItem(item);

        item = new Item("Whiteout", "2 fl.oz", 5);
        addItem(item);

        item = new Item("Tape", "Clear. 3 count box", 9);
        addItem(item);

        item = new Item("Scissors", "Grey", 2);
        addItem(item);

        User user = new User("bruce.wayne", "batman");
        addUser(user);

        user = new User("peter.parker", "spiderman");
        addUser(user);
    }

    // Adds new item to database
    public void addItem(Item item) {
        mDatabaseExecutor.execute(() -> {
            long itemId = mItemDao.addItem(item);
            item.setId(itemId);
        });
    }

    // Gets specific item from database
    public LiveData<Item> getItem(long itemId) {
        return mItemDao.getItem(itemId);
    }

    // Gets list of all items
    public LiveData<List<Item>> getItems() {
        return mItemDao.getItems();
    }

    // Updates specific item in database
    public void updateItem(Item item) {
        mDatabaseExecutor.execute(() -> mItemDao.updateItem(item));
    }

    // Deletes specific item in database
    public void deleteItem(Item item) {
        mDatabaseExecutor.execute(() -> mItemDao.deleteItem(item));
    }

    // Adds user to database
    public void addUser(User user) {
        mDatabaseExecutor.execute(() -> {
            long userId = mUserDao.addUser(user);
            user.setId(userId);
        });
    }

    // Gets specific user from database
    public LiveData<User> getUser(long userId) {
        return mUserDao.getUser(userId);
    }

    // Gets list of users from database
    public LiveData<List<User>> getUsers() {
        return mUserDao.getUsers();
    }

    // Updates user in database
    public void updateUser(User user) {
        mDatabaseExecutor.execute(() -> mUserDao.updateUser(user));
    }

    // Deletes specific user in database
    public void deleteUser(User user) {
        mDatabaseExecutor.execute(() -> mUserDao.deleteUser(user));
    }
}