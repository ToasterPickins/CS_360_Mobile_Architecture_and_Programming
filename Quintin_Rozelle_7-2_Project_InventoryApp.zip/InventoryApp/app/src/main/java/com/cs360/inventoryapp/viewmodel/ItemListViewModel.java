/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.cs360.inventoryapp.model.Item;
import com.cs360.inventoryapp.repo.AppRepository;

import java.util.List;

// View model for items
public class ItemListViewModel extends AndroidViewModel {

    private final AppRepository mAppRepository;

    // Constructor
    public ItemListViewModel(Application application) {
        super(application);
        mAppRepository = AppRepository.getInstance(application.getApplicationContext());
    }

    // Get list of items from repository
    public LiveData<List<Item>> getItems() {
        return mAppRepository.getItems();
    }

    // Add item to database through repository
    public void addItem(Item item) {
        mAppRepository.addItem(item);
    }

    // Update item in database through repository
    public void updateItem(Item item) {
        mAppRepository.updateItem(item);
    }

    // Delete item in database through repository
    public void deleteItem(Item item) {
        mAppRepository.deleteItem(item);
    }
}
