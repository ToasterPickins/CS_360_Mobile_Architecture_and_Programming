/**
 * Quintin B. Rozelle
 * 2/24/24
 * CS-360 Project 3
 * "Study Helper" and "To-Do List" apps from text book
 * used for basic structure. Additional functionality added
 */

package com.cs360.inventoryapp.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.cs360.inventoryapp.model.User;
import com.cs360.inventoryapp.repo.AppRepository;

import java.util.List;

// View model for users
public class UserViewModel extends AndroidViewModel {

    private final AppRepository mAppRepository;

    // Constructor
    public UserViewModel(@NonNull Application application) {
        super(application);
        mAppRepository = AppRepository.getInstance(application.getApplicationContext());
    }

    // Get list of users from repository
    public LiveData<List<User>> getUsers() {
        return mAppRepository.getUsers();
    }

    // Add user to database through repository
    public void addUser(User user) {
        mAppRepository.addUser(user);
    }

    // Update user in database through repository
    public void updateUser(User user) {
        mAppRepository.updateUser(user);
    }

    // Delete user in database through repository
    public void deleteUser(User user) {
        mAppRepository.deleteUser(user);
    }
}
