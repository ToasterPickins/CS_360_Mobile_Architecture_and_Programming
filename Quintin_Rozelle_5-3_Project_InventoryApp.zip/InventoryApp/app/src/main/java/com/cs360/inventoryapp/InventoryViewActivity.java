package com.cs360.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class InventoryViewActivity extends AppCompatActivity {

    private EditText mQuantity;
    private ImageButton mIncreaseButton;
    private ImageButton mDecreaseButton;
    private ImageButton mDeleteButton;
    private FloatingActionButton mAddFAB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_view);

        // Add onClickListeners
        mQuantity = findViewById(R.id.item_quantity);
        mIncreaseButton = findViewById(R.id.increase_button);
        mDecreaseButton = findViewById(R.id.decrease_button);
        mDeleteButton = findViewById(R.id.delete_button);
        mAddFAB = findViewById(R.id.inventory_add_button);

        mIncreaseButton.setOnClickListener(this::onIncreaseClick);
        mDecreaseButton.setOnClickListener(this::onDecreaseClick);
        mDeleteButton.setOnClickListener(this::onDeleteClick);
        mAddFAB.setOnClickListener(this::onAddClick);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // Starts settings activity to toggle SMS functionality
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.settings_button) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Increase quantity by 1
    private void onIncreaseClick(View view) {
        Integer mQuantityOnHand = Integer.parseInt(mQuantity.getText().toString());
        mQuantityOnHand++;
        mQuantity.setText(mQuantityOnHand.toString());
    }

    // Decreases quantity by 1
    private void onDecreaseClick(View view) {
        Integer mQuantityOnHand = Integer.parseInt(mQuantity.getText().toString());
        mQuantityOnHand--;
        mQuantity.setText(mQuantityOnHand.toString());
    }

    private void onDeleteClick(View view) {
        // TODO: Complete this method
    }

    // Launches Add New Item activity
    private void onAddClick(View view) {
        Intent intent = new Intent(this, AddItem.class);
        startActivity(intent);
    }
}