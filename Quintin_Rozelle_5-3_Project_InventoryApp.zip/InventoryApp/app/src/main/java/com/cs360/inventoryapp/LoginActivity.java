package com.cs360.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    private EditText mUserName;
    private EditText mPassword;
    private Button mLoginButton;
    private Button mRegisterButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Add onClickListeners
        mLoginButton = findViewById(R.id.login_button);
        mRegisterButton = findViewById(R.id.register_button);

        mLoginButton.setOnClickListener(this::onLoginClick);
        mRegisterButton.setOnClickListener(this::onRegisterClick);
    }

    // Launches inventory view activity
    private void onLoginClick(View view) {
        Intent intent = new Intent(this, InventoryViewActivity.class);
        startActivity(intent);
    }

    private void onRegisterClick(View view) {
        // TODO: Complete this method
    }
}