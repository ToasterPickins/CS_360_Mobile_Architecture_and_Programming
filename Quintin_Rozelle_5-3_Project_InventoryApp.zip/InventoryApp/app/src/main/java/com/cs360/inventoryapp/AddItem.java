package com.cs360.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class AddItem extends AppCompatActivity {

    private Button mAddButton;
    private Button mCancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Add onClickListeners
        mAddButton = findViewById(R.id.add_new_item_button);
        mCancelButton = findViewById(R.id.cancel_new_item_button);

        mAddButton.setOnClickListener(this::onAddClick);
        mCancelButton.setOnClickListener(this::onCancelClick);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.settings_button) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Start inventory activity
    private void onAddClick(View view) {
        Intent intent = new Intent(this, InventoryViewActivity.class);
        startActivity(intent);
    }

    private void onCancelClick(View view) {
        // TODO: Complete this method
    }
}